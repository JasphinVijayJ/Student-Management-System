package admin.dao.implement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import admin.dao.AdminDAO;
import admin.model.Admin;
import students.DBConnection.DBConnection;

public class AdminDAOImplement implements AdminDAO {

	@Override
	public Admin adminLogin(Admin admin) {
		
		String query = "select employee_email, employee_password from management where employee_email = ? and employee_password = ?";
		
		try {
			Connection conn = DBConnection.getConnection();
			PreparedStatement pre = conn.prepareStatement(query);
			
			pre.setString(1, admin.getAdminEmail());
			pre.setString(2, admin.getAdminPassword());
			
			ResultSet result = pre.executeQuery();
			
			if(result.next()) {
				return admin;	// Successful login
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;	// Login failed
	}

}
