package admin.dao;

import admin.model.Admin;

public interface AdminDAO {
	
//	Interfaces automatically treat all methods as public abstract, so you don’t need to write public explicitly.
	
	public Admin adminLogin(Admin admin);

}
