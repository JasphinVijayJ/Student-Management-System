package admin.controller;

import java.io.IOException;

import admin.dao.AdminDAO;
import admin.dao.implement.AdminDAOImplement;
import admin.model.Admin;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/adminLogin")
public class AdminLoginController extends HttpServlet{
	
	private AdminDAO adminDAO = new AdminDAOImplement();	// Creates an instance of AdminDAOImpl

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		
		String adminEmail = req.getParameter("adminemail");
		String adminPassword = req.getParameter("adminpassword");
		
		Admin admin = new Admin(adminEmail, adminPassword);
		
		Admin checkAdmin = adminDAO.adminLogin(admin);
		
		if(checkAdmin != null) {
			HttpSession session = req.getSession();	// Create a session
			session.setAttribute("admin", admin);	// Store admin details in session
			
			res.sendRedirect("Home.html");		// Redirect to home.html
		}
		else {
			res.sendRedirect("AdminLogin.html?error=Invalid Credentials"); // Redirect to login with error
		}
		
	}
}
