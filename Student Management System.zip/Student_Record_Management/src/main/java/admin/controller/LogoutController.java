package admin.controller;

import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/adminLogout")
public class LogoutController extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		HttpSession session = req.getSession(false);	//	false means it will return null if no session exists, instead of creating a new one.
		
		if(session != null) {
			session.invalidate();	//	If a session exists, it invalidates (destroys) it
		}
		res.sendRedirect("AdminLogin.html");
	}
}
