package students.Model;

public class Student {

	private int rollno;
	private String name;
	private int age;
	private String gender, email, phone, course;
	
	// Constructor
	public Student(int rollno1, String name1, int age1, String gender1, String email1, String phone1, String course1) {
		this.rollno = rollno1;
		this.name = name1;
		this.age = age1;
		this.gender = gender1;
		this.email = email1;
		this.phone = phone1;
		this.course = course1;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno2) {
		this.rollno = rollno2;
	}
	public String getName() {
		return name;
	}
	public void setName(String name2) {
		this.name = name2;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age2) {
		this.age = age2;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender2) {
		this.gender = gender2;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email2) {
		this.email = email2;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone2) {
		this.phone = phone2;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course2) {
		this.course = course2;
	}
}
