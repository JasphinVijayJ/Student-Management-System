package students.dao;

import java.util.List;

import students.Model.Student;

public interface StudentDAO {
	
//	Interfaces automatically treat all methods as public abstract, so you don’t need to write public explicitly.

	public int addStudent(Student student);
	public List<Student> getAllStudents();
	public Student getStudentByRollNo(int viewrollno);
	public void updateStudent(Student student);
	public void deleteStudent(int rollno);
}
