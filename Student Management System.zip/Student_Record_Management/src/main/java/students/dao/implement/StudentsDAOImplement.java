package students.dao.implement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import students.DBConnection.DBConnection;
import students.Model.Student;
import students.dao.StudentDAO;

public class StudentsDAOImplement implements StudentDAO{

	@Override
	public int addStudent(Student student) {

		String query = "insert into student values(?,?,?,?,?,?,?)";

		try {
			Connection conn = DBConnection.getConnection(); // DataBase Connection
			PreparedStatement pre = conn.prepareStatement(query);

			pre.setInt(1, student.getRollno());
			pre.setString(2, student.getName());
			pre.setInt(3, student.getAge());
			pre.setString(4, student.getGender());
			pre.setString(5, student.getEmail());
			pre.setString(6, student.getPhone());
			pre.setString(7, student.getCourse());

			return pre.executeUpdate(); // Returns 1 if success, 0 if failed
		} catch (SQLException e) {
			e.printStackTrace();
			return -1; // Database issue occurred.
		}
	}
	
	@Override
	public List<Student> getAllStudents() {
		
		List<Student> studentlist = new ArrayList<Student>();

		String query = "select * from student order by Roll_No";
		try {
			Connection conn = DBConnection.getConnection();		// DataBase Connection
			Statement st = conn.createStatement();
			ResultSet result = st.executeQuery(query);
			
			while(result.next()) {
				Student std = new Student(
						result.getInt("Roll_No"),
						result.getString("Name"),
						result.getInt("Age"),
						result.getString("Gender"),
						result.getString("Email"),
						result.getString("Phone"),
						result.getString("Course"));	// Column Names Must Match Database Table. Data go to Student Constructor
				
				studentlist.add(std);	// Store Student object in the request scope
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return studentlist;
	}
	
	@Override
	public Student getStudentByRollNo(int viewrollno) {
		
		String query = "select * from student where Roll_No = ?";

		Student std = null;
		try {
			Connection conn = DBConnection.getConnection();		// DataBase Connection
			PreparedStatement pre = conn.prepareStatement(query);
			
			pre.setInt(1, viewrollno);
			ResultSet result = pre.executeQuery();

			if(result.next()) {
				std = new Student(
						result.getInt("Roll_No"),
						result.getString("Name"),
						result.getInt("Age"),
						result.getString("Gender"),
						result.getString("Email"),
						result.getString("Phone"),
						result.getString("Course"));	// Column Names Must Match Database Table. Data go to Student Constructor
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return std;
	}

	@Override
	public void updateStudent(Student student) {

		String query = "update student set Name = ?, Age = ?, Gender = ?, Email = ?, Phone = ?, Course = ? where Roll_No = ?";
		
		try {
			Connection conn = DBConnection.getConnection(); // DataBase Connection
			PreparedStatement pre = conn.prepareStatement(query);

			pre.setString(1, student.getName());
			pre.setInt(2, student.getAge());
			pre.setString(3, student.getGender());
			pre.setString(4, student.getEmail());
			pre.setString(5, student.getPhone());
			pre.setString(6, student.getCourse());
			pre.setInt(7, student.getRollno());
			
			pre.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteStudent(int rollno) {

		String query = "delete from student where Roll_No = ?";

		try {
			Connection conn = DBConnection.getConnection(); // DataBase Connection
			PreparedStatement pre = conn.prepareStatement(query);
			
			pre.setInt(1, rollno);
			
			pre.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
