package students.controller;

import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import students.dao.StudentDAO;
import students.dao.implement.StudentsDAOImplement;

@WebServlet("/deleteStudent")
public class DeleteStudentServlet extends HttpServlet{
	
	private StudentDAO studentDAO = new StudentsDAOImplement();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		
		int rollno = Integer.parseInt(req.getParameter("rollno"));
		
		studentDAO.deleteStudent(rollno);
		
		res.sendRedirect("Home.html");		// Redirect to home.html
	}
}
