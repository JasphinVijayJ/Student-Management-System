package students.controller;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import students.Model.Student;
import students.dao.StudentDAO;
import students.dao.implement.StudentsDAOImplement;

@WebServlet("/displayOneStudent")
public class GetStudentByRollNoServlet extends HttpServlet{
	
	private StudentDAO studentDAO = new StudentsDAOImplement();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		int viewrollno = Integer.parseInt(req.getParameter("viewrollno"));
		
		Student student = studentDAO.getStudentByRollNo(viewrollno);
		
		req.setAttribute("student", student);	// Store Student object in the request scope
		
		RequestDispatcher dis = req.getRequestDispatcher("DisplayOne_2.jsp");
		dis.forward(req, res);
	}
}
