package students.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import students.Model.Student;
import students.dao.StudentDAO;
import students.dao.implement.StudentsDAOImplement;

@WebServlet("/displayall")
public class GetAllStudentsServlet extends HttpServlet {

	private StudentDAO studentDAO = new StudentsDAOImplement();	 // Creates an instance of StudentDAOImpl

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		List<Student> studentslist = studentDAO.getAllStudents();

		req.setAttribute("studentslist", studentslist); // Pass the student list to JSP

		// Forward request to DisplayAll.jsp
		RequestDispatcher dis = req.getRequestDispatcher("DisplayAll.jsp");
		dis.forward(req, res);
	}
}
