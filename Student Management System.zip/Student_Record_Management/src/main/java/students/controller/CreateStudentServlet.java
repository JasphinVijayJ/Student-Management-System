package students.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import students.Model.Student;
import students.dao.StudentDAO;
import students.dao.implement.StudentsDAOImplement;

@WebServlet("/createStudent")
public class CreateStudentServlet extends HttpServlet{
	
	private StudentDAO studentDAO = new StudentsDAOImplement();	 // Creates an instance of StudentDAOImpl
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException  {
		
		int rollno = Integer.parseInt(req.getParameter("rollno"));
		String name = req.getParameter("name");
		int age = Integer.parseInt(req.getParameter("age"));
		String gender = req.getParameter("gender");
		String email = req.getParameter("email");
		String phone = req.getParameter("phone");
		String course = req.getParameter("course");
		
		Student std = new Student(rollno, name, age, gender, email, phone, course);	 // Data go to Student Constructor
		
		studentDAO.addStudent(std);	// Calls method from StudentDAOImpl
		
		res.sendRedirect("Home.html");		// Redirect to home.html
	}
}
