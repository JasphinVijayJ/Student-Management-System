package students.controller;

import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import students.Model.Student;
import students.dao.StudentDAO;
import students.dao.implement.StudentsDAOImplement;

@WebServlet("/updateStudent")
public class UpdateStudentServlet extends HttpServlet{
	
	private StudentDAO studentDAO = new StudentsDAOImplement();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		
		int rollno = Integer.parseInt(req.getParameter("rollno"));
		String newname = req.getParameter("newname");
		int newage = Integer.parseInt(req.getParameter("newage"));
		String newgender = req.getParameter("newgender");
		String newemail = req.getParameter("newemail");
		String newphone = req.getParameter("newphone");
		String newcourse = req.getParameter("newcourse");
		
		Student std = new Student(rollno, newname, newage, newgender, newemail, newphone, newcourse);	// Data go to Student Constructor
		
		studentDAO.updateStudent(std);
		
		res.sendRedirect("Home.html");		// Redirect to home.html
	}
}
